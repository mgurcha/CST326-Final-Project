﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camera : MonoBehaviour
{
	public GameObject target;
    void Start()
    {
        
    }

   
    void Update()
    {
		// transform.RotateAround(target.transform.position, target.transform.up, 20 * Time.deltaTime);
    }
}
